package com.KamilIsmail.MovieApp.DTO;

/**
 * @author kamilismail
 */
public class BooleanDTO {

    private Boolean result;

    public BooleanDTO(Boolean result) {
        this.result = result;
    }

    public Boolean getResult() {
        return result;
    }

    public void setResult(Boolean result) {
        this.result = result;
    }
}
