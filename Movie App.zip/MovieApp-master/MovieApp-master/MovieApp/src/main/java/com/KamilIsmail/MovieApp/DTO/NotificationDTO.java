package com.KamilIsmail.MovieApp.DTO;

/**
 * @author kamilismail
 */
public class NotificationDTO {

    public NotificationDTO () {

    }
}
